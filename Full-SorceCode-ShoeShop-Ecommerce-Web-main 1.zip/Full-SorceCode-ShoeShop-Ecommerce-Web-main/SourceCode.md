

4.  # SERVER DEPENDENCIES

    npm install bcryptjs dotenv express express-async-handler jsonwebtoken mongoose morgan
    npm install -D concurrently nodemon

5.  # SERVER .ENV

    PORT =
    NODE_ENV
    JWT_SECRET
    PAYPAL_CLIENT_ID
    MONGO_URL
